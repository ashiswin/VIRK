<?php
	require_once "utils/database.php";
	require_once "connectors/EventConnector.php";
	
	$eventid = intval($_POST['eventid']);
	$password = $_POST['password'];
	
	$EventConnector = new EventConnector($conn);
	
	$event = $EventConnector->select($eventid);
	
	if(strcmp($event["logoutpass"], $password) == 0) {
		$response["success"] = true;
	}
	else {
		$response["success"] = false;
		$response["message"] = "Invalid password provided";
	}
	
	echo(json_encode($response));
?>
