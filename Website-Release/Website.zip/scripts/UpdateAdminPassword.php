<?php
	function random_str($length, $keyspace = '0123456789abcdefghijklmnopqrstuvwxyz')
	{
		$str = '';
		$max = mb_strlen($keyspace, '8bit') - 1;
		for ($i = 0; $i < $length; ++$i) {
			$str .= $keyspace[random_int(0, $max)];
		}
		return $str;
	}
	
	$adminid = trim($_POST['adminid']);
	$current = trim($_POST['current']);
	$newPass = trim($_POST['newpass']);
	
	$response = array();
	
	require_once 'utils/database.php';
	require_once 'connectors/AdminConnector.php';
	
	$AdminConnector = new AdminConnector($conn);
	$result = $AdminConnector->selectById($adminid);
	if(!$result) {
		$response["message"] = "Uable to select admin";
		$response["error"] = true;
		$response["success"] = false;
		
		echo(json_encode($response));
		return;
	}
	
	$passwordHash = hash('sha512', ($current . $result[AdminConnector::$COLUMN_SALT]));
	if(!strcmp($passwordHash, $result[AdminConnector::$COLUMN_PASSWORD]) == 0) {
		$response["success"] = false;
		$response["error"] = true;
		$response["message"] = "Invalid username or password!";
		
		echo(json_encode($response));
		return;
	}
	
	$salt = random_str(10);
	$password = hash('sha512', ($newPass . $salt));
	
	if(!$AdminConnector->updatePassword($password, $salt, $adminid)) {
		$response["message"] = "An error occurred while updating password";
		$response["success"] = false;
	}
	else {
		$response["success"] = true;
	}
	
	echo(json_encode($response));
?>
