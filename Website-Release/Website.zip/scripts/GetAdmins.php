<?php
	require_once "utils/database.php";
	require_once "connectors/AdminConnector.php";
	
	$adminid = intval($_GET['adminid']);
	
	$AdminConnector = new AdminConnector($conn);
	$admins = $AdminConnector->selectAll();
	
	for($i = 0; $i < count($admins); $i++) {
		if(intval($admins[$i]["id"]) == $adminid) {
			unset($admins[$i]);
			break;
		}
	}
	
	$response["success"] = true;
	$response["admins"] = array_values($admins);
	
	echo(json_encode($response));
?>
