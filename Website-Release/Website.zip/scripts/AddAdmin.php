<?php
	function random_str($length, $keyspace = '0123456789abcdefghijklmnopqrstuvwxyz')
        // Creates a random string
        // $length is an int and decides how long the output string is
        // Default keyspace is alphanumeric
	{
		$str = '';
		$max = mb_strlen($keyspace, '8bit') - 1; // $max limits random_int to within the keyspace
		for ($i = 0; $i < $length; ++$i) {
			$str .= $keyspace[random_int(0, $max)];
		}
		return $str;
	}
	
	require_once 'utils/database.php';
	require_once 'connectors/AdminConnector.php';
	
	$AdminConnector = new AdminConnector($conn); // AdminConnector has a whole bunch of prepare statements for queries 
	if(count($AdminConnector->select($_POST['username'])) > 0) { // If there is another of this username in Database
		$response["message"] = "This username has been taken";
		$response["success"] = false;
		
		echo(json_encode($response)); // Return error message
		return;
	}
	
	$username = $_POST['username'];
	$salt = random_str(10); // create random str of length 10
	$password = hash('sha512', ($_POST['password'] . $salt)); // hash the password
	$name = $_POST['name'];
	$result = $AdminConnector->create($username, $password, $salt, $name); // create name Admin using username, hashed password, salt and name
	
	if(!$result) { // If it didn't work for some reason
		$response["message"] = "Invalid username or password!";
		$response["success"] = false;
	}
	else {	
		$response["success"] = true;
	}
	
	echo(json_encode($response)); // Return error message
?>
