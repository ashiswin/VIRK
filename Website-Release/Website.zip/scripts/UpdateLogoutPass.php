<?php
	require_once "utils/database.php";
	require_once "connectors/EventConnector.php";
	
	$eventid = $_POST['eventid'];
	$logoutpass = $_POST['logoutpass'];
	
	$EventConnector = new EventConnector($conn);
	$response["success"] = $EventConnector->updateLogoutPass($logoutpass, $eventid);
	
	echo(json_encode($response));
?>
