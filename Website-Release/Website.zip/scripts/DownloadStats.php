<?php
	require_once "utils/database.php";
	require_once "connectors/EventConnector.php";
	require_once "connectors/GroupConnector.php";
	
	$eventid = $_GET['id'];
	
	$EventConnector = new EventConnector($conn);
	$event = $EventConnector->select($eventid);
	
	$GroupConnector = new GroupConnector($conn);
	$groups = $GroupConnector->selectGroupsByEvent($eventid);
	
	header('Content-type: text/csv');
	header('Content-Disposition: attachment; filename="' . $event['name'] . ' - Statistics.csv"');
	header('Content-Transfer-Encoding: binary');
	
	
	echo("#,Group Name, Members, 1 Star, 2 Stars, 3 Stars, Score\n");
	
	for($i = 0; $i < count($groups); $i++) {
		$membersArray = explode("|", $groups[$i]["members"]);
		$members = "";
		for($j = 0; $j < count($membersArray); $j += 2) {
			$members .= $membersArray[$j + 1] . " (" . $membersArray[$j] . ")";
			if($j != count($membersArray) - 2) {
				$members .= "; ";
			}
		}
		
		$votesArray = explode("|", $groups[$i]["votes"]);
		$votes = 0;
		$stars = array(0, 0, 0);
		
		for($j = 0; $j < count($votesArray); $j++) {
			if(strlen($votesArray[$j]) < 7 && strcmp($votesArray[$j], "") != 0 && intval($votesArray[$j]) != 0) {
				$votes += intval($votesArray[$j]);
				$stars[intval($votesArray[$j]) - 1]++;
			}
		}
		
		echo(($i + 1) . "," . $groups[$i]["name"] . "," . $members . ",");
		for($j = 0; $j < count($stars); $j++) {
			echo($stars[$j] . ",");
		}
		echo($votes . "\n");
	}
?>
