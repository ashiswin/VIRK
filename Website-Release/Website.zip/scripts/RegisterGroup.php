<?php
	require_once "utils/database.php";
	require_once "connectors/GroupConnector.php";
	require_once "connectors/EventConnector.php";
	
	$eventid = $_POST['eventid'];
	$groupid = $_POST['groupid'];
	$password = trim($_POST['password']);
	
	$GroupConnector = new GroupConnector($conn);
	$group = $GroupConnector->selectGroup($eventid, $groupid);
	
	if(strcmp($group['password'], $password) == 0) {
		$EventConnector = new EventConnector($conn);
		$event = $EventConnector->select($eventid);
		
		$response["success"] = true;
		$response["groupname"] = $group['name'];
		$response["event"] = $event;
	}
	else {
		$response["success"] = false;
		$response["message"] = "Invalid password entered!";
	}
	
	echo(json_encode($response));
?>
