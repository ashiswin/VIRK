<?php
    ini_set("auto_detect_line_endings", true);
    
    function remove_utf8_bom($text)
    //this function removes BOM characters
    {
        $bom = pack('H*','EFBBBF');
        $text = preg_replace("/^$bom/", '', $text);
        return $text;
    }

    function random_str(
    $length = 6,
    $keyspace = '23456789abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ'
    ) {
        $str = '';
        $max = mb_strlen($keyspace, '8bit') - 1;
        if ($max < 1) {
            throw new Exception('$keyspace must be at least two characters long');
        }
        for ($i = 0; $i < $length; ++$i) {
            $str .= $keyspace[random_int(0, $max)];
        }
        return $str;
    }
    function multiexplode ($delimiters, $string) {
	$ready = str_replace($delimiters, $delimiters[0], $string);
	$launch = explode($delimiters[0], $ready);
	return  $launch;
    }
    
    if(isset($_FILES['group_list'])){
        try {
            // Undefined | Multiple Files | $_FILES Corruption Attack
            // If this request falls under any of them, treat it invalid.
            if (
                !isset($_FILES['group_list']['error']) ||
                is_array($_FILES['group_list']['error'])
            ) {
                throw new RuntimeException('Invalid parameters.');
            }

            // Check $_FILES['upfile']['error'] value.
            switch ($_FILES['group_list']['error']) {
                case UPLOAD_ERR_OK:
                    break;
                case UPLOAD_ERR_NO_FILE:
                    throw new RuntimeException('No file sent.');
                case UPLOAD_ERR_INI_SIZE:
                    throw new RuntimeException('Exceeded filesize limit.');
                case UPLOAD_ERR_FORM_SIZE:
                    throw new RuntimeException('Exceeded filesize limit.');
                default:
                    throw new RuntimeException('Unknown errors.');
            }

            // You should also check filesize here. 
            if ($_FILES['group_list']['size'] > 1000000) {
                throw new RuntimeException('Exceeded filesize limit.');
            }

            // DO NOT TRUST $_FILES['upfile']['mime'] VALUE !!
            // Check MIME Type by yourself.
            $listOfMIME = array(
                'text/comma-separated-values', 
                'text/csv', 
                'application/csv', 
                'application/excel', 
                'application/vnd.ms-excel', 
                'application/vnd.msexcel', 
                'text/anytext');
                
            if(!in_array($_FILES['group_list']['type'], $listOfMIME) ||
                substr($_FILES['group_list']['name'], -4) !== '.csv')
            {
                throw new RuntimeException('Invalid file format.');
            }
            
            // Need to check if the file itself is in Group Name, Student ID, Student Name format
            $group_list = fopen($_FILES['group_list']['tmp_name'], 'rb');
            $line = fgetcsv($group_list);
            
            if($line != false){
                $item1 = remove_utf8_bom(trim($line[0]));
                $item2 = remove_utf8_bom(trim($line[1]));
                $item3 = remove_utf8_bom(trim($line[2]));
                
                if(!is_string($item1) || 
                   !ctype_digit($item2) || 
                   !ctype_alpha($item3))
                {
                    throw new RuntimeException('CSV entries need to be in the format, "Group Name, Student ID, Student Name."');
                }   
            } 

        } catch (RuntimeException $e) {
		$response = array();
		$response["message"] = $e->getMessage();
		$response["success"] = false;
		
		die(json_encode($response));
        }
    }

	$event_name = trim($_POST['event_name']);
	$date = trim($_POST['date']);
	$start = trim($_POST['start']);
	$end = trim($_POST['end']);
	$min = trim($_POST['min']);
	$max = trim($_POST['max']);
	$reward = trim($_POST['reward']);
	$adminid = trim($_POST['adminid']);
        
	require_once "utils/database.php";
	require_once "connectors/EventConnector.php";
    require_once "connectors/GroupConnector.php";
	
	$EventConnector = new EventConnector($conn);
    $GroupConnector = new GroupConnector($conn);
	$result = $EventConnector->create($event_name, $date, $start, $end, $min, $max, $reward, $adminid);

	if(!$result) {
		$response["message"] = "Event not created";
		$response["success"] = false;
	}
	else {
		$response["message"] = "Event created";
		$response["eventid"] = $result;
		$response["success"] = true;
        
		$groups = array();
		while ($line != false) {
		    $group_name = remove_utf8_bom(trim($line[0]));
		    $members = '';
		    foreach($line as $item){
			$item = remove_utf8_bom(trim($item));
			if($item != $group_name and $item != ''){
			    $members .= $item . '|';
			}
		    }
		    
		    $members = rtrim(trim($members), '|');
		    $group_password = random_str();
		    $check_list = array();
		    
		    while($GroupConnector->checkUniquePW($group_password) == false ||
		          array_search($group_password, $check_list) != false)
		    {
		        $group_password = random_str();
		    }
		    
		    
		    $GroupConnector->createGroup($group_name, $members, $group_password, $result);
		    $line = fgetcsv($group_list);
		}
		fclose($group_list);
	}

	echo(json_encode($response));
?>
