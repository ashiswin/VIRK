<?php
	require_once "utils/database.php";
	require_once "connectors/EventConnector.php";
	require_once "connectors/GroupConnector.php";
	require_once "connectors/VoterConnector.php";
	require_once "connectors/RedemptionConnector.php";
	
	$eventid = $_POST['eventid'];
	
	$EventConnector = new EventConnector($conn);
	$GroupConnector = new GroupConnector($conn);
	$VoterConnector = new VoterConnector($conn);
	$RedemptionConnector = new RedemptionConnector($conn);
	
	$EventConnector->delete($eventid);
	$GroupConnector->deleteEvent($eventid);
	$VoterConnector->deleteEvent($eventid);
	$RedemptionConnector->deleteEvent($eventid);
	
	$response["success"] = true;
	
	echo(json_encode($response));
?>
