<?php
	require_once "utils/database.php";
	require_once "connectors/TagConnector.php";
	
	$tagid = $_POST['tagid'];
	
	$TagConnector = new TagConnector($conn);
	$TagConnector->delete($tagid);
	
	$response["success"] = true;
	
	echo(json_encode($response));
?>
