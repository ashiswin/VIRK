<?php
	function random_str($length, $keyspace = '0123456789abcdefghijklmnopqrstuvwxyz')
	{
		$str = '';
		$max = mb_strlen($keyspace, '8bit') - 1;
		for ($i = 0; $i < $length; ++$i) {
			$str .= $keyspace[random_int(0, $max)];
		}
		return $str;
	}
	
	require_once 'utils/database.php';
	require_once 'connectors/AdminConnector.php';
	
	$AdminConnector = new AdminConnector($conn);
	$username = "admin";
	$salt = random_str(10);
	$password = hash('sha512', ("password" . $salt));
	$name = "admin";
	$result = $AdminConnector->create($username, $password, $salt, $name);
	if(!$result) {
		$response["message"] = "Invalid username or password!";
		$response["error"] = true;
		$response["success"] = false;
	}
	else {	
		$response["success"] = true;
		$response["error"] = false;
	}
	
	echo(json_encode($response));
?>
