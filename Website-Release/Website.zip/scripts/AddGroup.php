<?php
	require_once "utils/database.php";
	require_once "connectors/GroupConnector.php";
	
	function random_str($length = 6, $keyspace = '23456789abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ') {
		$str = '';
		$max = mb_strlen($keyspace, '8bit') - 1;
		if ($max < 1) {
			throw new Exception('$keyspace must be at least two characters long');
		}
		for ($i = 0; $i < $length; ++$i) {
			$str .= $keyspace[random_int(0, $max)];
		}
		return $str;
	}
	
	$eventid = $_POST['eventid'];
	$name = $_POST['name'];
	$members = $_POST['members'];
	$password = random_str();

	$GroupConnector = new GroupConnector($conn); // GroupConnector has bunch of prepare statements for queries
	$result = $GroupConnector->createGroup($name, $members, $password, $eventid); // Create new group
	
	if(!$result) {
		$response["success"] = false;
		$response["message"] = "Failed to add group";
	}
	else {
		$response["success"] = true;
		$response["groupid"] = $result;
	}
	
	echo(json_encode($response));
?>
