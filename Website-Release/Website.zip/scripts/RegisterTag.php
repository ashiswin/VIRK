<?php
	require_once "utils/database.php";
	require_once "connectors/TagConnector.php";
	
	$tagid = $_POST['tagid'];
	$studentid = $_POST['studentid'];
	
	$TagConnector = new TagConnector($conn);
	
	$response["success"] = $TagConnector->create($tagid, $studentid);
	
	if(!$resonse["success"]) {
		$response["message"] = "This tag or student ID has already been registered";
	}
	
	echo(json_encode($response));
?>
