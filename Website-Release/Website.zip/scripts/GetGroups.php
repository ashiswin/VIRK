<?php
	require_once "utils/database.php";
	require_once "connectors/GroupConnector.php";
	
	$eventid = $_GET['id'];
	
	$GroupConnector = new GroupConnector($conn);
	$groups = $GroupConnector->selectGroupsByEvent($eventid);
	
	$response["success"] = true;
	$response["groups"] = $groups;
	
	echo(json_encode($response));
?>
