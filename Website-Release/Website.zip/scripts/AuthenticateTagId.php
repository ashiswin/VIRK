<?php
	require_once "utils/database.php";
	require_once "connectors/VoterConnector.php";
	require_once "connectors/GroupConnector.php";
	require_once "connectors/EventConnector.php";
	require_once "connectors/TagConnector.php";
	
	$tagId = $_POST['tagId'];
	$eventid = intval($_POST['eventid']);
	$groupid = intval($_POST['groupid']);
	
	$TagConnector = new TagConnector($conn);
	$student = $TagConnector->select($tagId); // Checks if the TagID exists in Database
	if($student == false) {
		$response["success"] = false;
		$response["message"] = "This tag has not been registered for voting";
		
		echo(json_encode($response));
		return;
	}
	
	$studentid = $student["studentid"];
	
	$VoterConnector = new VoterConnector($conn);
	if($VoterConnector->selectIfVoted($studentid, $eventid, $groupid) != 0) {
		$response["success"] = false;
		$response["message"] = "You have already voted for this group";
		
		echo(json_encode($response));
		return;
	}
	
	$GroupConnector = new GroupConnector($conn);
	$group = $GroupConnector->selectGroup($eventid, $groupid);
	
	if(strpos($group["members"], $studentid) !== false) {
		$response["success"] = false;
		$response["message"] = "You cannot vote for your own group";
		
		echo(json_encode($response));
		return;
	}
	
	$EventConnector = new EventConnector($conn);
	$event = $EventConnector->select($eventid);
	
	if($VoterConnector->selectNumberVotes($studentid, $eventid) >= $event['max']) {
		$response["success"] = false;
		$response["message"] = "You have reached the maximum number of votes";
		
		echo(json_encode($response));
		return;
	}
	
	$response["success"] = true;
	$response["studentid"] = $studentid;
	
	echo(json_encode($response));
