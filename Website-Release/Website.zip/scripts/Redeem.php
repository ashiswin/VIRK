<?php
	require_once "utils/database.php";
	require_once "utils/websocket.php";
	require_once "connectors/RedemptionConnector.php";
	
	$studentid = $_POST['studentid'];
	$eventid = intval($_POST['eventid']);
	
	$RedemptionConnector = new RedemptionConnector($conn);
	
	$result = $RedemptionConnector->select($studentid, $eventid);
	if(!$result) {
		$RedemptionConnector->create($studentid, $eventid);
		// Update stats server
		$ws = new ws(array
		(
			'host' => 'devostrum.no-ip.info',
			'port' => 8080,
			'path' => ''
		));
		$result = $ws->send("update:" . $eventid . ":" . $studentid);
		$ws->close();
		
		$response["success"] = true;
		echo(json_encode($response));
	}
	else {
		$response["success"] = false;
		$response["message"] = "You have already redeemed your reward";
		echo(json_encode($response));
	}
?>
