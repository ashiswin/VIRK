<?php
	$conn = new mysqli("localhost", "<Enter User Username>", "<Enter User Password>", "virk");
	if($conn->connect_error) {
		$response["success"] = false;
		$response["message"] = "Connection failed: " . $conn->connect_error;
	} 
?>
