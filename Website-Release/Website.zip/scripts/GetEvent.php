<?php
	require_once "utils/database.php";
	require_once "connectors/EventConnector.php";
	require_once "connectors/GroupConnector.php";
	require_once "connectors/RedemptionConnector.php";
	require_once "connectors/VoterConnector.php";
	
	$eventid = $_GET['eventid'];
	
	$EventConnector = new EventConnector($conn);
	$event = $EventConnector->select($eventid);
	
	$GroupConnector = new GroupConnector($conn);
	$groups = $GroupConnector->selectGroupsByEvent($eventid);
	
	$RedemptionConnector = new RedemptionConnector($conn);
	$redemptions = $RedemptionConnector->selectTotalRedemptions($eventid);
	
	$VoterConnector = new VoterConnector($conn);
	$voters = $VoterConnector->selectUniqueVoters($eventid);
	
	$attendees = null;

	for($i = 0; $i < count($voters); $i++) {
		$attendees[$voters[$i]["studentid"]] += 1;
	}
    
	$response["success"] = true;
	$response["event"] = $event;
	$response["event"]["groups"] = $groups;
	$response["event"]["attendees"] = $attendees;
	$response["event"]["redemptions"] = $redemptions;
	
	echo(json_encode($response));
?>
