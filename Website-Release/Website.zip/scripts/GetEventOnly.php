<?php
	require_once "utils/database.php";
	require_once "connectors/EventConnector.php";
	require_once "connectors/GroupConnector.php";
	require_once "connectors/RedemptionConnector.php";
	require_once "connectors/VoterConnector.php";
	
	$eventid = $_GET['eventid'];
	
	$EventConnector = new EventConnector($conn);
	$event = $EventConnector->select($eventid);
	
	$response["success"] = true;
	$response["event"] = $event;
	
	echo(json_encode($response));
?>
