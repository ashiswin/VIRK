<?php
	class RedemptionConnector {
		private $mysqli = NULL;
		
		public static $TABLE_NAME = "redemptions";
		public static $COLUMN_ID = "id";
		public static $COLUMN_STUDENTID = "studentid";
		public static $COLUMN_EVENTID = "eventid";
		
		private $createStatement = NULL;
		private $selectStatement = NULL;
		private $selectTotalRedemptionsStatement = NULL;
		private $deleteStatement = NULL;
		
		function __construct($mysqli) {
			if($mysqli->connect_errno > 0){
				die('Unable to connect to database [' . $mysqli->connect_error . ']');
			}
			
			$this->mysqli = $mysqli;
			
			$this->createStatement = $mysqli->prepare("INSERT INTO " . RedemptionConnector::$TABLE_NAME . "(`" . RedemptionConnector::$COLUMN_STUDENTID . "`, `" . RedemptionConnector::$COLUMN_EVENTID . "`) VALUES(?, ?)");
			$this->selectStatement = $mysqli->prepare("SELECT * FROM `" . RedemptionConnector::$TABLE_NAME . "` WHERE `" . RedemptionConnector::$COLUMN_STUDENTID . "` = ? AND `" . RedemptionConnector::$COLUMN_EVENTID . "` = ?");
			$this->selectTotalRedemptionsStatement = $mysqli->prepare("SELECT COUNT(*) FROM `" . RedemptionConnector::$TABLE_NAME . "` WHERE `" . RedemptionConnector::$COLUMN_EVENTID . "` = ?");
			$this->deleteStatement = $mysqli->prepare("DELETE FROM " . RedemptionConnector::$TABLE_NAME . " WHERE `" . RedemptionConnector::$COLUMN_ID . "` = ?");
			$this->deleteEventStatement = $mysqli->prepare("DELETE FROM " . RedemptionConnector::$TABLE_NAME . " WHERE `" . RedemptionConnector::$COLUMN_EVENTID . "` = ?");
		}
		
		public function create($studentid, $eventid) {
			$this->createStatement->bind_param("si", $studentid, $eventid);
			return $this->createStatement->execute();
		}
		
		public function select($studentid, $eventid) {
			$this->selectStatement->bind_param("si", $studentid, $eventid);
			if(!$this->selectStatement->execute()) return false;

			$result = $this->selectStatement->get_result();
			if(!$result) return false;
			$redemption = $result->fetch_assoc();
			
			$this->selectStatement->free_result();
			
			return $redemption;
		}
		public function selectTotalRedemptions($eventid) {
			$this->selectTotalRedemptionsStatement->bind_param("i", $eventid);
			if(!$this->selectTotalRedemptionsStatement->execute()) return false;
			$this->selectTotalRedemptionsStatement->store_result();
			$this->selectTotalRedemptionsStatement->bind_result($redemptions);
			$this->selectTotalRedemptionsStatement->fetch();
			
			$this->selectTotalRedemptionsStatement->free_result();
			
			return $redemptions;
		}

		public function delete($id) {
			if($id == NULL) return false;
			
			$this->deleteStatement->bind_param("i", $id);
			if(!$this->deleteStatement->execute()) return false;
			
			return true;
		}
		
		public function deleteEvent($eventid) {
			if($eventid == NULL) return false;
			
			$this->deleteEventStatement->bind_param("i", $eventid);
			if(!$this->deleteEventStatement->execute()) return false;
			
			return true;
		}
	}
?>
