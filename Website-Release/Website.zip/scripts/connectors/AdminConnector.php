<?php
	class AdminConnector {
		private $mysqli = NULL;
		
		public static $TABLE_NAME = "admins";
		public static $COLUMN_ID = "id";
		public static $COLUMN_USERNAME = "username";
		public static $COLUMN_PASSWORD = "password";
		public static $COLUMN_NAME = "name";
		public static $COLUMN_SALT = "salt";
		
		private $createStatement = NULL;
		private $selectStatement = NULL;
		private $selectByIdStatement = NULL;
		private $selectAllStatement = NULL;
		private $deleteStatement = NULL;
		
		function __construct($mysqli) {
			if($mysqli->connect_errno > 0){
				die('Unable to connect to database [' . $mysqli->connect_error . ']');
			}
			
			$this->mysqli = $mysqli;
			
			$this->createStatement = $mysqli->prepare("INSERT INTO " . AdminConnector::$TABLE_NAME . "(`" . AdminConnector::$COLUMN_USERNAME . "`, `" . AdminConnector::$COLUMN_PASSWORD . "`, `" . AdminConnector::$COLUMN_SALT . "`, `" . AdminConnector::$COLUMN_NAME . "`) VALUES(?, ?, ?, ?)");
			$this->selectStatement = $mysqli->prepare("SELECT * FROM `" . AdminConnector::$TABLE_NAME . "` WHERE `" . AdminConnector::$COLUMN_USERNAME . "` = ?");
			$this->selectByIdStatement = $mysqli->prepare("SELECT * FROM `" . AdminConnector::$TABLE_NAME . "` WHERE `" . AdminConnector::$COLUMN_ID . "` = ?");
			$this->selectAllStatement = $mysqli->prepare("SELECT * FROM `" . AdminConnector::$TABLE_NAME . "`");
			$this->deleteStatement = $mysqli->prepare("DELETE FROM " . AdminConnector::$TABLE_NAME . " WHERE `" . AdminConnector::$COLUMN_ID . "` = ?");
		}
		
		public function create($username, $passwordHash, $salt, $name) {
			if($username == NULL) return false;
			
			$this->createStatement->bind_param("ssss", $username, $passwordHash, $salt, $name);
			return $this->createStatement->execute();
		}
		
		public function select($username) {
			if($username == NULL) return false;
			
			$this->selectStatement->bind_param("s", $username);
			if(!$this->selectStatement->execute()) return false;

			$result = $this->selectStatement->get_result();
			if(!$result) return false;
			$admin = $result->fetch_assoc();
			
			$this->selectStatement->free_result();
			
			return $admin;
		}
		public function selectById($adminid) {
			$this->selectByIdStatement->bind_param("i", $adminid);
			if(!$this->selectByIdStatement->execute()) return false;

			$result = $this->selectByIdStatement->get_result();
			if(!$result) return false;
			$admin = $result->fetch_assoc();
			
			$this->selectByIdStatement->free_result();
			
			return $admin;
		}
		public function selectAll() {
			if(!$this->selectAllStatement->execute()) return false;
			$result = $this->selectAllStatement->get_result();
			$resultArray = $result->fetch_all(MYSQLI_ASSOC);
			return $resultArray;
		}
		
		public function updatePassword($password, $salt, $adminid) {
			$updateQuery = "UPDATE " . AdminConnector::$TABLE_NAME . " SET ";
			$updateQuery .= "`" . AdminConnector::$COLUMN_PASSWORD . "` = \"" . $password . "\"";
			$updateQuery .= ", `" . AdminConnector::$COLUMN_SALT . "` = \"" . $salt . "\"";
			$updateQuery .= " WHERE `" . AdminConnector::$COLUMN_ID . "` = \"" . $adminid . "\"";
			
			if(!$this->mysqli->query($updateQuery)) return false;
			return true;
		}
		
		public function delete($id) {
			$this->deleteStatement->bind_param("i", $id);
			if(!$this->deleteStatement->execute()) return false;
			
			return true;
		}
	}
?>
