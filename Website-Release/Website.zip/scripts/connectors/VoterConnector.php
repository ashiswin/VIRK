<?php
	class VoterConnector {
		private $mysqli = NULL;
		
		public static $TABLE_NAME = "voters";
		public static $COLUMN_ID = "id";
		public static $COLUMN_STUDENTID = "studentid";
		public static $COLUMN_EVENTID = "eventid";
		public static $COLUMN_GROUPID = "groupid";
		
		private $createStatement = NULL;
		private $selectNumberVotesStatement = NULL;
		private $deleteStatement = NULL;
		
		function __construct($mysqli) {
			if($mysqli->connect_errno > 0){
				die('Unable to connect to database [' . $mysqli->connect_error . ']');
			}
			
			$this->mysqli = $mysqli;
			          
			$this->createStatement = $mysqli->prepare("INSERT INTO " . VoterConnector::$TABLE_NAME . "(" . VoterConnector::$COLUMN_STUDENTID . ", " . VoterConnector::$COLUMN_EVENTID . ", " . VoterConnector::$COLUMN_GROUPID . ") VALUES (?, ?, ?)");
            
			$this->selectNumberVotesStatement = $mysqli->prepare("SELECT COUNT(*) FROM " . VoterConnector::$TABLE_NAME . " WHERE " . VoterConnector::$COLUMN_STUDENTID . "=? AND " . VoterConnector::$COLUMN_EVENTID . "=?");
			$this->selectIfVotedStatement = $mysqli->prepare("SELECT COUNT(*) FROM " . VoterConnector::$TABLE_NAME . " WHERE " . VoterConnector::$COLUMN_STUDENTID . "=? AND " . VoterConnector::$COLUMN_EVENTID . "=? AND " . VoterConnector::$COLUMN_GROUPID . "=?");
			$this->selectUniqueVotersStatement = $mysqli->prepare("SELECT `voters`.`studentid` FROM `voters` LEFT JOIN `tags` ON `tags`.`studentid`=`voters`.`studentid` WHERE `voters`.`eventid`=?");
			$this->deleteStatement = $mysqli->prepare("DELETE FROM " . VoterConnector::$TABLE_NAME . " WHERE " . VoterConnector::$COLUMN_ID . "=?");
			$this->deleteEventStatement = $mysqli->prepare("DELETE FROM " . VoterConnector::$TABLE_NAME . " WHERE " . VoterConnector::$COLUMN_EVENTID . "=?");
		}
		
		public function createVote($studentid, $eventid, $groupid) {
			$this->createStatement->bind_param("sii", $studentid, $eventid, $groupid);
			
			if(!$this->createStatement->execute()){
				die('Query failed: ' . $this->createStatement->error);
			}			

			return $this->mysqli->insert_id;
		}
		
		public function selectNumberVotes($studentid, $eventid) {
			$this->selectNumberVotesStatement->bind_param("si", $studentid, $eventid);
			if(!$this->selectNumberVotesStatement->execute()) return false;
			$this->selectNumberVotesStatement->store_result();
			$this->selectNumberVotesStatement->bind_result($votes);
			$this->selectNumberVotesStatement->fetch();
			
			$this->selectNumberVotesStatement->free_result();
			
			return $votes;
		}
		
		public function selectIfVoted($studentid, $eventid, $groupid) {
			$this->selectIfVotedStatement->bind_param("sii", $studentid, $eventid, $groupid);
			if(!$this->selectIfVotedStatement->execute()) return false;
			$this->selectIfVotedStatement->store_result();
			$this->selectIfVotedStatement->bind_result($votes);
			$this->selectIfVotedStatement->fetch();
			
			$this->selectIfVotedStatement->free_result();
			
			return $votes;
		}
		
		public function selectUniqueVoters($eventid) {
			$this->selectUniqueVotersStatement->bind_param("i", $eventid);
			if(!$this->selectUniqueVotersStatement->execute()) return false;
			$result = $this->selectUniqueVotersStatement->get_result();
			$resultArray = $result->fetch_all(MYSQLI_ASSOC);
			return $resultArray;
		}
		
		public function deleteVote($voteid) {
			$this->deleteStatement->bind_param("i", $voteid);
			if(!$this->deleteStatement->execute()) return false;
			
			return true;
		}
		
		public function deleteEvent($eventid) {
			$this->deleteEventStatement->bind_param("i", $eventid);
			if(!$this->deleteEventStatement->execute()) return false;
			
			return true;
		}
	}
?>
