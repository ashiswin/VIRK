<?php
	$date = trim($_POST['date']);
	$start = trim($_POST['start']);
	$end = trim($_POST['end']);
	$min = trim($_POST['min']);
	$max = trim($_POST['max']);
	$reward = trim($_POST['reward']);
	$eventid = trim($_POST['eventid']);
        
	require_once "utils/database.php";
	require_once "connectors/EventConnector.php";
	
	$EventConnector = new EventConnector($conn);
	$result = $EventConnector->update($date, $start, $end, $min, $max, $reward, $eventid);

	if(!$result) {
		$response["message"] = "Event not updated";
		$response["success"] = false;
	}
	else {
		$response["message"] = "Event updated";
		$response["success"] = true;
	}

	echo(json_encode($response));
?>
